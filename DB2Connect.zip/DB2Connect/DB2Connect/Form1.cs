﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IBM.Data.DB2;


namespace DB2Connect
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DB2Connection myConn       = null;
            DB2Command myCommand       = null;
            DB2DataReader myDataReader = null;
            string strDB2Data          = null;
            string strConnectString    = null;
            string strPassword         = null;

            // try putting double-quotes around the password
            strPassword =  "\"" +PasswordBox.Text + "\"" ;

            strConnectString = "Server="         +
                                HostBox.Text     +
                                ";Database="     +
                                DatabaseBox.Text +
                                ";UID="          +
                                UseridBox.Text   +
                                ";PWD="          +
                                strPassword ;
           
            try
            {

                Cursor.Current = Cursors.WaitCursor;
                myConn = new DB2Connection(strConnectString);
                myConn.Open();
                myCommand = myConn.CreateCommand();
                myCommand.CommandText = "SELECT CURRENT SERVER FROM SYSIBM.SYSDUMMY1";
                myDataReader = myCommand.ExecuteReader();

                while (myDataReader.Read())
                {
                    if (!myDataReader.IsDBNull(0))
                      strDB2Data = myDataReader.GetString(0);
                }
                               
                ResultBox.Text = "Connection: OK     SELECT CURRENT SERVER: "+ strDB2Data;


            }
            catch (Exception ex)
            {
                ResultBox.Text = ex.Message;
            }

            if (myDataReader != null)
            {
                myDataReader.Close();
                myCommand.Dispose();
            }

            if (myConn != null)
             myConn.Close();

           Cursor.Current = Cursors.Default;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
